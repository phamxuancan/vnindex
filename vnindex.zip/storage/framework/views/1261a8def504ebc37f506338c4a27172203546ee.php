<?php /* C:\xampp\htdocs\vnindex\resources\views/sort.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-bordered table-hover">
            <thead>
            <tr>
                <th class="font-weight-bold width-stand text_small text-center">Code</th>
                <th class="font-weight-bold width-stand text_small text-center">NNMUA</th>
                <th class="font-weight-bold width-stand text_small text-center">NNBAN</th>
                <th class="font-weight-bold width-stand text_small text-center">CHÊNH LỆCH</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td  class="font-weight-bold width-stand text_small text-center" >
                    <a href="<?php echo e(route('display-vnindex',['code' => $data->code])); ?>"><?php echo e($data->code); ?></a>
                    </td>
                <td  class="font-weight-bold width-stand text_small text-center <?php echo e(($data->tong_mua == 0)?'alert-success':''); ?>" ><?php echo e($data->tong_mua); ?></td>
                <td  class="font-weight-bold width-stand text_small text-center <?php echo e(($data->tong_ban == 0)?'alert-success':''); ?>" ><?php echo e($data->tong_ban); ?></td>
                <td  class="font-weight-bold width-stand text_small text-center" ><?php echo e($data->nfsdf); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>