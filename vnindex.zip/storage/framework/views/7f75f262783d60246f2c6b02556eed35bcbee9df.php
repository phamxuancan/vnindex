<?php /* C:\xampp\htdocs\vnindex\resources\views/vnindex.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-bordered table-hover">
            <thead>
            <tr>
                <?php $i =0;  ?>
                <th></th>
                <?php $__currentLoopData = $data_date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>" colspan="4"><?php echo e($date); ?></th>
                    <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <tr>
            <td  class="font-weight-bold width-stand text_small text-center" >Mã</td>
            <?php $i =0;  ?>
                <?php $__currentLoopData = $data_date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="font-weight-bold width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>">TC</td>
                <td class="font-weight-bold width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>">KL</td>
                <td class="font-weight-bold width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>">NNMUA</td>
                <td class="font-weight-bold width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>">NNBAN</td>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th class="font-weight-bold width-stand text_small text-center"> CN </th>
            </tr>
            <?php $__currentLoopData = $array_by_date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td  class="width-stand text_small text-center <?php echo e(($data[0]['stock']['eps']*$data[0]['stock']['pe']) > ($data[0]['thamchieu']*1000) ?'bg-success':'fff'); ?>" title="<?php echo e($data[0]['stock']['companyName']); ?>  - <?php echo e($data[0]['stock']['industryName']); ?>"><?php echo e($key); ?> (<?php echo e(number_format($data[0]['stock']['eps']*$data[0]['stock']['pe'])); ?>)</td>
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $b_i = $i-1;
                        
                        // dd($data[$b_i]['thamchieu']);
                        $class_change = '';
                        if( $b_i > -1 && $t['thamchieu'] < $data[$b_i]['thamchieu']){
                            $class_change = 'giam';
                        }
                        if($b_i > -1 && $t['thamchieu'] > $data[$b_i]['thamchieu']){
                            $class_change = 'tang';
                        }
                        if($b_i > -1 && $t['thamchieu'] == $data[$b_i]['thamchieu']){
                            $class_change = 'bang';
                        }
                        // dd($data[$b_i]['thamchieu']);
                    ?>
                        <td class="width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?> <?php echo e($class_change); ?>"><?php echo e($t['thamchieu']); ?></td>
                        <td class="width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>"><?php echo e($t['khoiluong']); ?></td>
                        <td class="width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>"><?php echo e($t['nnmua']); ?></td>
                        <td class="width-stand text_small text-center <?php echo e(($i%2==0)?'odd':'even'); ?>"><?php echo e($t['nnban']); ?></td>
                        <?php $i++;  ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td  class="font-weight-bold width-stand text_small text-center" >
                        <div class="dropdown">
                            <button class="text_small btn btn-sm btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Action
                            </button>
                            <div class="text_small dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="text_small dropdown-item" href="<?php echo e(route('display-vnindex',['category' => $t['stock']['industryName']])); ?>">Cùng Ngành</a>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>